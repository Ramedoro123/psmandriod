package com.example.myapplication.com.example.whm.ui.OrderDetailsList

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class OrderDetailsAdapter (private val OrderDetails:List<OrderDetailsModelList>,var activity:Context?):RecyclerView.Adapter<OrderDetailsAdapter.ViewHolder>()
{
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        TODO("Not yet implemented")


    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): OrderDetailsAdapter.ViewHolder {
        TODO("Not yet implemented")


    }



    override fun getItemCount(): Int {
        TODO("Not yet implemented")


    }
    inner class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {


    }
}