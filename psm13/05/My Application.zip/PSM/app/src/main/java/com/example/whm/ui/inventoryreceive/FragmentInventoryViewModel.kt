package com.example.whm.ui.inventoryreceive

import androidx.lifecycle.ViewModel

class FragmentInventoryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}