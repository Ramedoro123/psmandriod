package com.example.whm.ui.Piker_And_Packer_OrderList

import android.app.Dialog
import android.graphics.Color
import android.os.Bundle
import android.preference.PreferenceManager
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication.R
import com.example.myapplication.com.example.whm.AppPreferences
import com.example.myapplication.com.example.whm.ui.OrderList.ModelClassOrderLIst
import com.example.myapplication.com.example.whm.ui.Piker_And_Packer_OrderList.AdapterClass.OrderListAdapter
import org.json.JSONObject
import java.lang.Exception


class OrderListFragment : Fragment() {
    private val orderList = ArrayList<ModelClassOrderLIst>()
    private lateinit var orderlistAdapter: OrderListAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(
            // Inflate the layout for this fragment
            R.layout.fragment_order_list2,
            container,
            false
        )
        view.requestFocus()
        view.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                }
            }
            true
        })
        if (AppPreferences.internetConnectionCheck(this.context)) {
            val recyclerView: RecyclerView = view.findViewById(R.id.OrderListfragement)
            val sharedUnloadOrderPreferences =
                PreferenceManager.getDefaultSharedPreferences(this.context)
            var UnloadOrderCount = sharedUnloadOrderPreferences.getString("UnloadOrder", "[0]")
            setHasOptionsMenu(true)
            orderlistAdapter = OrderListAdapter(orderList, this.context)
            val layoutManager = LinearLayoutManager(this.context)
            recyclerView.layoutManager = layoutManager
            recyclerView.itemAnimator = DefaultItemAnimator()
            recyclerView.adapter = orderlistAdapter
            //here is call valley library
            val Jsonarra = JSONObject()
            val JSONObj = JSONObject()
            val pobj = JSONObject()
            val pDialog = SweetAlertDialog(this.context, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.progressHelper.barColor = Color.parseColor("#A5DC86")
            pDialog.titleText = "Fetching ..."
            pDialog.setCancelable(false)
            pDialog.show()
            val preferences = PreferenceManager.getDefaultSharedPreferences(context)
            var accessToken =
                preferences.getString("accessToken", "a2d8fjhsdkfhsbdpsmnjgxzn3d8xy7jewbc7x")
            JSONObj.put(
                "requestContainer", Jsonarra.put(
                    "deviceID",
                    Settings.Secure.getString(context?.contentResolver, Settings.Secure.ANDROID_ID)
                )
            )
            val queues = Volley.newRequestQueue(this.context)
            JSONObj.put("requestContainer", Jsonarra.put("appVersion", AppPreferences.AppVersion))
            JSONObj.put("requestContainer", Jsonarra.put("accessToken", accessToken))
            JSONObj.put("pobj", pobj)
            val queue = Volley.newRequestQueue(this.context)
// Request a string response from the provided URL.
            val JsonObjectRequest =
                JsonObjectRequest(Request.Method.POST, AppPreferences.API_PICKER_AND_PACKER,
                    JSONObj, { response ->
                        // Display the first 500 characters of the response string.
                        val resobj = (response.toString())
                        val responsemsg = JSONObject(resobj.toString())
                        val resultobj = JSONObject(responsemsg.getString("d"))
                        val resmsg = resultobj.getString("responseMessage")
                        val rescode = resultobj.getString("responseCode")
                        if (rescode == "200") {
                            val responsData = resultobj.getJSONArray("responseData")
                            var Status: String
                            Status = ""
                            for (i in 0 until responsData.length()) {
                                val OrderNo = responsData.getJSONObject(i).getString("ONo")
                                val Customer = responsData.getJSONObject(i).getString("CName")
                                val salesPerson = responsData.getJSONObject(i).getString("SName")
                                val ShippingType = responsData.getJSONObject(i).getString("ST")
                                val Products = responsData.getJSONObject(i).getString("ONo")
                                Status = responsData.getJSONObject(i).getString("Status")
                                val ColorCode=responsData.getJSONObject(i).getString("ColorCode")
                                val OrderDate = responsData.getJSONObject(i).getString("ODate")
                                val StatusAutoId=responsData.getJSONObject(i).getInt("StatusAutoId")
                                    StatusAutoId.toInt().toString()
                                val TotalNoOfItem=responsData.getJSONObject(i).getInt("TotalNoOfItem")
                                // var StatusColor:RecyclerView=view.findViewById(R.id.StatusView)
                                if (StatusAutoId==2) {
                                    OrderListData(
                                        OrderNo,
                                        Customer,
                                        salesPerson,
                                        ShippingType,
                                        Products,
                                        Status,
                                        OrderDate,
                                        ColorCode,
                                        StatusAutoId,
                                        TotalNoOfItem


                                    )
                                }
                            }
                            pDialog.dismiss()
                        } else {
                            pDialog.dismiss()
                        }
                    },

                    Response.ErrorListener {
                        pDialog.dismiss()
                    })
            JsonObjectRequest.retryPolicy = DefaultRetryPolicy(
                10000000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

// Add the request to the RequestQueue.
            try {
                queue.add(JsonObjectRequest)
            } catch (e: Exception) {
                Toast.makeText(this.context, "Server Error", Toast.LENGTH_LONG).show()
            }

        } else {
            val dialog = context?.let { Dialog(it) }
            dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog?.setContentView(com.example.myapplication.R.layout.dailog_log)
            val btDismiss =
                dialog?.findViewById<Button>(com.example.myapplication.R.id.btDismissCustomDialog)
            btDismiss?.setOnClickListener {
                dialog.dismiss()
                this.findNavController().navigate(com.example.myapplication.R.id.nav_home)
            }
            dialog?.show()
        }
        return view
    }

    private fun OrderListData(
        OrderNo: String,
        Customer: String,
        salesPerson: String,
        ShippingType: String,
        Products: String,
        Status: String,
        OrderDate: String,
        ColorCode:String,
       StatusAutoId:Int,
        TotalNoOfItem:Int
    ) {
        var order = ModelClassOrderLIst(
            OrderNo,
            Customer,
            salesPerson,
            ShippingType,
            Products,
            Status,
            OrderDate,
            ColorCode,
            StatusAutoId,
            TotalNoOfItem
        )
        orderList.add(order)
        orderlistAdapter.notifyDataSetChanged()
    }
}

