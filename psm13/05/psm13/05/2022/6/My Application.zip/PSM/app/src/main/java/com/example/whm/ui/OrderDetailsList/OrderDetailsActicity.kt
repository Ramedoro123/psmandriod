package com.example.whm.ui.OrderDetailsList

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.R
import com.example.myapplication.com.example.whm.ui.OrderDetailsList.OrderDetailsAdapter
import com.example.myapplication.com.example.whm.ui.OrderDetailsList.OrderDetailsModelList

class OrderDetailsActicity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_details_acticity)

        val orderListDetails = ArrayList<OrderDetailsModelList>()
        lateinit var orderDetailsAdapter: OrderDetailsAdapter



    }
}