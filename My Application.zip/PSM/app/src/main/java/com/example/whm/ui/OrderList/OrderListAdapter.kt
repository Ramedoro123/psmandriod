package com.example.myapplication.com.example.whm.ui.OrderList

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.provider.VoicemailContract
import android.provider.VoicemailContract.Status
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import javax.net.ssl.SSLEngineResult

class OrderListAdapter(private val OderList: List<ModelClassOrderLIst>,var activity: Context?) : RecyclerView.Adapter<OrderListAdapter.ViewHolder>() {

    // Holds the views for adding it to image and text
   inner class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        var OrderNo:TextView=ItemView.findViewById(R.id.OrderNo)
        var Customer:TextView=ItemView.findViewById(R.id.Customer)
        var salesPerson:TextView=ItemView.findViewById(R.id.SalesPerson)
        var ShippingType:TextView=ItemView.findViewById(R.id.ShippingTypeView)
        var Products:TextView=ItemView.findViewById(R.id.ProductView)
        var Status:TextView=ItemView.findViewById(R.id.StatusView)
        var OrderDate:TextView=ItemView.findViewById(R.id.OrderDate)
        var StausView:TextView=ItemView.findViewById(R.id.StatusView)
        var Start:TextView=ItemView.findViewById(R.id.StartPageView)
        var ViewButton:TextView=ItemView.findViewById(R.id.ViewPageView)

    }
    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context).inflate(R.layout.orderlist_view, parent, false)
        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val OrderList=OderList[position]
        holder.OrderNo.text=OrderList.getOrderNo()
        holder.Customer.text=OrderList.getCustomer()
        holder.salesPerson.text=OrderList.getsalesPerson()
        holder.ShippingType.text=OrderList.getShippingType()
        holder.Products.text=OrderList.getProducts()
        holder.OrderDate.text=OrderList.getOrderDate()
        holder.Status.text=OrderList.getStatus()
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return OderList.size
    }


}